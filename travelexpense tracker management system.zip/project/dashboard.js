// Dashboard module for Expense Tracker

class Dashboard {
  constructor() {
    this.charts = {};
    this.init();
  }

  init() {
    this.setupEventListeners();
    this.setupCharts();
    
    // Update dashboard when it becomes visible
    this.update();
  }

  setupEventListeners() {
    // Navigation items
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const section = item.dataset.section;
        this.switchSection(section);
      });
    });

    // Sidebar toggle
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    
    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', () => this.toggleSidebar());
    }
    
    if (mobileMenuToggle) {
      mobileMenuToggle.addEventListener('click', () => this.toggleMobileSidebar());
    }

    // Theme toggle
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
      themeToggle.addEventListener('click', () => this.toggleTheme());
    }

    // Quick action buttons
    const addExpenseButtons = document.querySelectorAll('#add-expense-btn, #add-expense-btn-2');
    const addTripButtons = document.querySelectorAll('#add-trip-btn, #add-trip-btn-2');
    
    addExpenseButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        Utils.resetForm('expense-form');
        Utils.openModal('expense-modal');
      });
    });
    
    addTripButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        Utils.resetForm('trip-form');
        Utils.openModal('trip-modal');
      });
    });

    // Filter changes
    const filters = document.querySelectorAll('.filter-select');
    filters.forEach(filter => {
      filter.addEventListener('change', () => {
        const section = this.getCurrentSection();
        if (section === 'expenses') {
          window.expenseManager?.filterExpenses();
        } else if (section === 'trips') {
          window.expenseManager?.filterTrips();
        }
      });
    });

    // Report export buttons
    const exportPdfBtn = document.getElementById('export-pdf-btn');
    const exportCsvBtn = document.getElementById('export-csv-btn');
    
    if (exportPdfBtn) {
      exportPdfBtn.addEventListener('click', () => this.exportPDF());
    }
    
    if (exportCsvBtn) {
      exportCsvBtn.addEventListener('click', () => this.exportCSV());
    }

    // Modal close handlers
    const modalCloseButtons = document.querySelectorAll('.modal-close, [data-modal]');
    modalCloseButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (e.target === e.currentTarget || btn.classList.contains('modal-close')) {
          const modalId = btn.dataset.modal;
          if (modalId) {
            Utils.closeModal(modalId);
          }
        }
      });
    });

    // Close modal on background click
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          Utils.closeModal(modal.id);
        }
      });
    });

    // Window resize handler
    window.addEventListener('resize', Utils.throttle(() => {
      this.handleResize();
    }, 250));
  }

  setupProfileDropdown() {
    const profileDropdown = document.querySelector('.profile-dropdown');
    const profileToggle = document.querySelector('.profile-toggle');
    const editProfileBtn = document.getElementById('edit-profile-btn');
    const changeAvatarBtn = document.getElementById('change-avatar-btn');
    const accountSettingsBtn = document.getElementById('account-settings-btn');
    const exportDataBtn = document.getElementById('export-data-btn');
    const profileLogoutBtn = document.getElementById('profile-logout-btn');
    
    // Toggle dropdown
    if (profileDropdown && profileToggle) {
      profileToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        profileDropdown.classList.toggle('active');
      });
      
      // Close dropdown when clicking outside
      document.addEventListener('click', (e) => {
        if (!profileDropdown.contains(e.target)) {
          profileDropdown.classList.remove('active');
        }
      });
    }
    
    // Profile menu actions
    if (editProfileBtn) {
      editProfileBtn.addEventListener('click', () => {
        this.openEditProfile();
        profileDropdown.classList.remove('active');
      });
    }
    
    if (changeAvatarBtn) {
      changeAvatarBtn.addEventListener('click', () => {
        this.openChangeAvatar();
        profileDropdown.classList.remove('active');
      });
    }
    
    if (accountSettingsBtn) {
      accountSettingsBtn.addEventListener('click', () => {
        Utils.showToast('Account settings feature coming soon!', 'info');
        profileDropdown.classList.remove('active');
      });
    }
    
    if (exportDataBtn) {
      exportDataBtn.addEventListener('click', () => {
        this.exportCSV();
        profileDropdown.classList.remove('active');
      });
    }
    
    if (profileLogoutBtn) {
      profileLogoutBtn.addEventListener('click', () => {
        window.auth?.logout();
        profileDropdown.classList.remove('active');
      });
    }
    
    // Edit profile form
    const editProfileForm = document.getElementById('edit-profile-form');
    if (editProfileForm) {
      editProfileForm.addEventListener('submit', (e) => this.handleEditProfile(e));
    }
    
    // Avatar selection
    this.setupAvatarSelection();
  }

  openEditProfile() {
    const user = window.auth?.getCurrentUser();
    if (!user) return;
    
    // Populate form with current user data
    document.getElementById('profile-name').value = user.name || '';
    document.getElementById('profile-email').value = user.email || '';
    document.getElementById('profile-role').value = user.role || 'Traveler';
    document.getElementById('profile-avatar-url').value = user.customAvatar || '';
    
    Utils.openModal('edit-profile-modal');
  }

  handleEditProfile(event) {
    event.preventDefault();
    
    const name = document.getElementById('profile-name').value.trim();
    const email = document.getElementById('profile-email').value.trim();
    const role = document.getElementById('profile-role').value.trim();
    const avatarUrl = document.getElementById('profile-avatar-url').value.trim();
    
    if (!name || !email) {
      Utils.showToast('Name and email are required', 'error');
      return;
    }
    
    if (!Utils.validateEmail(email)) {
      Utils.showToast('Please enter a valid email address', 'error');
      return;
    }
    
    // Update user data
    const user = window.auth?.getCurrentUser();
    if (user) {
      user.name = name;
      user.email = email;
      user.role = role || 'Traveler';
      if (avatarUrl) {
        user.customAvatar = avatarUrl;
        user.avatar = avatarUrl;
      }
      
      // Save updated user data
      Utils.saveToStorage('currentUser', user);
      
      // Update users array
      const users = Utils.getFromStorage('users', []);
      const userIndex = users.findIndex(u => u.id === user.id);
      if (userIndex !== -1) {
        users[userIndex] = { ...users[userIndex], ...user };
        Utils.saveToStorage('users', users);
      }
      
      // Update UI
      window.auth?.updateUserInfo();
      this.updateProfileDropdown();
      
      Utils.closeModal('edit-profile-modal');
      Utils.showToast('Profile updated successfully!', 'success');
    }
  }

  openChangeAvatar() {
    Utils.openModal('change-avatar-modal');
  }

  setupAvatarSelection() {
    const avatarOptions = document.querySelectorAll('.avatar-option');
    const avatarUpload = document.getElementById('avatar-upload');
    const avatarPreview = document.getElementById('avatar-preview');
    const saveAvatarBtn = document.getElementById('save-avatar-btn');
    let selectedAvatar = null;
    
    // Handle preset avatar selection
    avatarOptions.forEach(option => {
      option.addEventListener('click', () => {
        // Remove previous selection
        avatarOptions.forEach(opt => opt.classList.remove('selected'));
        
        // Select current option
        option.classList.add('selected');
        selectedAvatar = option.dataset.avatar;
        
        // Clear upload preview
        avatarPreview.innerHTML = '';
      });
    });
    
    // Handle custom avatar upload
    if (avatarUpload) {
      avatarUpload.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
          try {
            // Validate file
            if (!file.type.startsWith('image/')) {
              Utils.showToast('Please select an image file', 'error');
              return;
            }
            
            if (file.size > 2 * 1024 * 1024) { // 2MB limit
              Utils.showToast('Image size must be less than 2MB', 'error');
              return;
            }
            
            // Read file and show preview
            const dataURL = await Utils.readFileAsDataURL(file);
            selectedAvatar = dataURL;
            
            avatarPreview.innerHTML = `<img src="${dataURL}" alt="Avatar Preview">`;
            
            // Clear preset selection
            avatarOptions.forEach(opt => opt.classList.remove('selected'));
            
          } catch (error) {
            Utils.handleError(error, 'Avatar Upload');
          }
        }
      });
    }
    
    // Save avatar
    if (saveAvatarBtn) {
      saveAvatarBtn.addEventListener('click', () => {
        if (!selectedAvatar) {
          Utils.showToast('Please select an avatar', 'error');
          return;
        }
        
        const user = window.auth?.getCurrentUser();
        if (user) {
          user.avatar = selectedAvatar;
          user.customAvatar = selectedAvatar;
          
          // Save updated user data
          Utils.saveToStorage('currentUser', user);
          
          // Update users array
          const users = Utils.getFromStorage('users', []);
          const userIndex = users.findIndex(u => u.id === user.id);
          if (userIndex !== -1) {
            users[userIndex] = { ...users[userIndex], ...user };
            Utils.saveToStorage('users', users);
          }
          
          // Update UI
          window.auth?.updateUserInfo();
          this.updateProfileDropdown();
          
          Utils.closeModal('change-avatar-modal');
          Utils.showToast('Avatar updated successfully!', 'success');
          
          // Reset form
          avatarOptions.forEach(opt => opt.classList.remove('selected'));
          avatarPreview.innerHTML = '';
          avatarUpload.value = '';
          selectedAvatar = null;
        }
      });
    }
  }

  updateProfileDropdown() {
    const user = window.auth?.getCurrentUser();
    if (!user) return;
    
    // Update profile menu header
    const profileMenuName = document.getElementById('profile-menu-name');
    const profileMenuEmail = document.getElementById('profile-menu-email');
    const profileMenuAvatar = document.querySelector('.profile-menu-avatar');
    
    if (profileMenuName) profileMenuName.textContent = user.name;
    if (profileMenuEmail) profileMenuEmail.textContent = user.email;
    if (profileMenuAvatar) profileMenuAvatar.src = user.avatar;
  }

  switchSection(sectionName) {
    // Update navigation
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
      item.classList.remove('active');
      if (item.dataset.section === sectionName) {
        item.classList.add('active');
      }
    });

    // Update content sections
    const contentSections = document.querySelectorAll('.content-section');
    contentSections.forEach(section => {
      section.classList.remove('active');
    });

    const targetSection = document.getElementById(`${sectionName}-content`);
    if (targetSection) {
      targetSection.classList.add('active');
      Utils.animateElement(targetSection, 'fade-in');
    }

    // Update page title
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      const titles = {
        dashboard: 'Dashboard',
        expenses: 'Expenses',
        trips: 'Trips',
        analytics: 'Analytics',
        reports: 'Reports'
      };
      pageTitle.textContent = titles[sectionName] || 'Dashboard';
    }

    // Close mobile sidebar if open
    if (Utils.isMobile()) {
      this.closeMobileSidebar();
    }

    // Update section-specific data
    this.updateSectionData(sectionName);
  }

  getCurrentSection() {
    const activeNavItem = document.querySelector('.nav-item.active');
    return activeNavItem ? activeNavItem.dataset.section : 'dashboard';
  }

  updateSectionData(sectionName) {
    switch (sectionName) {
      case 'dashboard':
        this.updateDashboardStats();
        this.updateRecentActivity();
        break;
      case 'expenses':
        if (window.expenseManager) {
          window.expenseManager.renderExpenses();
        }
        break;
      case 'trips':
        if (window.expenseManager) {
          window.expenseManager.renderTrips();
        }
        break;
      case 'analytics':
        this.updateCharts();
        break;
      case 'reports':
        // Reports section doesn't need real-time updates
        break;
    }
  }

  toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.toggle('collapsed');
      
      // Save preference
      const isCollapsed = sidebar.classList.contains('collapsed');
      Utils.saveToStorage('sidebarCollapsed', isCollapsed);
    }
  }

  toggleMobileSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.toggle('open');
    }
  }

  closeMobileSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.remove('open');
    }
  }

  toggleTheme() {
    const newTheme = Utils.toggleTheme();
    
    // Update theme toggle button
    const themeToggle = document.getElementById('theme-toggle');
    const themeIcon = themeToggle?.querySelector('i');
    const themeText = themeToggle?.querySelector('span');
    
    if (themeIcon && themeText) {
      if (newTheme === 'light') {
        themeIcon.className = 'fas fa-sun';
        themeText.textContent = 'Light Mode';
      } else {
        themeIcon.className = 'fas fa-moon';
        themeText.textContent = 'Dark Mode';
      }
    }

    Utils.showToast(`Switched to ${newTheme} mode`, 'success');
  }

  updateDashboardStats() {
    if (!window.auth?.isAuthenticated()) return;

    const user = window.auth.getCurrentUser();
    const expenses = Utils.getFromStorage(`expenses_${user.id}`, []);
    const trips = Utils.getFromStorage(`trips_${user.id}`, []);

    // Calculate totals
    const totalExpenses = expenses.reduce((sum, expense) => sum + (parseFloat(expense.amount) || 0), 0);
    const pendingCount = expenses.filter(expense => expense.status === 'pending').length;
    const approvedCount = expenses.filter(expense => expense.status === 'approved').length;

    // Update stat cards
    this.updateStatCard('total-expenses', Utils.formatCurrency(totalExpenses));
    this.updateStatCard('total-trips', trips.length.toString());
    this.updateStatCard('pending-count', pendingCount.toString());
    this.updateStatCard('approved-count', approvedCount.toString());
  }

  updateStatCard(elementId, value) {
    const element = document.getElementById(elementId);
    if (element && element.textContent !== value) {
      // Add animation for value change
      element.style.transform = 'scale(1.1)';
      element.textContent = value;
      
      setTimeout(() => {
        element.style.transform = 'scale(1)';
      }, 200);
    }
  }

  updateRecentActivity() {
    if (!window.auth?.isAuthenticated()) return;

    const user = window.auth.getCurrentUser();
    const expenses = Utils.getFromStorage(`expenses_${user.id}`, []);
    const trips = Utils.getFromStorage(`trips_${user.id}`, []);

    // Combine and sort by date
    const allItems = [
      ...expenses.map(item => ({ ...item, type: 'expense' })),
      ...trips.map(item => ({ ...item, type: 'trip' }))
    ].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
     .slice(0, 5); // Show only 5 most recent

    const container = document.getElementById('recent-activity');
    if (container) {
      if (allItems.length === 0) {
        container.innerHTML = `
          <div class="empty-state">
            <i class="fas fa-inbox"></i>
            <p>No recent activity. Add your first expense or trip!</p>
          </div>
        `;
      } else {
        container.innerHTML = allItems.map(item => this.createRecentActivityItem(item)).join('');
      }
    }
  }

  createRecentActivityItem(item) {
    const icon = item.type === 'expense' ? Utils.getCategoryIcon(item.category) : 'fas fa-plane';
    const amount = item.type === 'expense' ? Utils.formatCurrency(item.amount) : Utils.formatCurrency(item.budget || 0);
    const date = Utils.formatDate(item.createdAt || item.date);
    
    return `
      <div class="recent-item">
        <div class="recent-icon">
          <i class="${icon}"></i>
        </div>
        <div class="recent-content">
          <div class="recent-title">${item.title}</div>
          <div class="recent-meta">
            <span class="recent-type">${item.type === 'expense' ? 'Expense' : 'Trip'}</span>
            <span class="recent-date">${date}</span>
          </div>
        </div>
        <div class="recent-amount">${amount}</div>
        <div class="recent-status">
          <span class="item-status status-${item.status}">${item.status}</span>
        </div>
      </div>
    `;
  }

  setupCharts() {
    // Initialize charts when Chart.js is available
    if (typeof Chart !== 'undefined') {
      this.initializeCharts();
    } else {
      // Wait for Chart.js to load
      const checkChart = setInterval(() => {
        if (typeof Chart !== 'undefined') {
          clearInterval(checkChart);
          this.initializeCharts();
        }
      }, 100);
    }
  }

  initializeCharts() {
    // Expense Pie Chart
    const expenseChartCanvas = document.getElementById('expense-chart');
    if (expenseChartCanvas) {
      this.charts.expenseChart = new Chart(expenseChartCanvas, {
        type: 'doughnut',
        data: {
          labels: [],
          datasets: [{
            data: [],
            backgroundColor: [
              '#ff6b6b', // food
              '#4ecdc4', // transport
              '#45b7d1', // accommodation
              '#96ceb4', // entertainment
              '#ffeaa7'  // other
            ],
            borderWidth: 2,
            borderColor: '#1f1f1f'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                color: getComputedStyle(document.documentElement).getPropertyValue('--text-primary'),
                padding: 20,
                usePointStyle: true
              }
            }
          }
        }
      });
    }

    // Monthly Trends Chart
    const monthlyChartCanvas = document.getElementById('monthly-chart');
    if (monthlyChartCanvas) {
      this.charts.monthlyChart = new Chart(monthlyChartCanvas, {
        type: 'line',
        data: {
          labels: [],
          datasets: [{
            label: 'Monthly Expenses',
            data: [],
            borderColor: '#e50914',
            backgroundColor: 'rgba(229, 9, 20, 0.1)',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              labels: {
                color: getComputedStyle(document.documentElement).getPropertyValue('--text-primary')
              }
            }
          },
          scales: {
            x: {
              ticks: {
                color: getComputedStyle(document.documentElement).getPropertyValue('--text-secondary')
              },
              grid: {
                color: getComputedStyle(document.documentElement).getPropertyValue('--border-color')
              }
            },
            y: {
              ticks: {
                color: getComputedStyle(document.documentElement).getPropertyValue('--text-secondary'),
                callback: function(value) {
                  return '$' + value;
                }
              },
              grid: {
                color: getComputedStyle(document.documentElement).getPropertyValue('--border-color')
              }
            }
          }
        }
      });
    }

    // Update charts with initial data
    this.updateCharts();
  }

  updateCharts() {
    if (!window.auth?.isAuthenticated()) return;

    const user = window.auth.getCurrentUser();
    const expenses = Utils.getFromStorage(`expenses_${user.id}`, []);
    const stats = Utils.calculateStats(expenses);

    // Update expense pie chart
    if (this.charts.expenseChart) {
      const categories = Object.keys(stats.byCategory);
      const amounts = Object.values(stats.byCategory);
      
      this.charts.expenseChart.data.labels = categories.map(cat => {
        const categoryNames = {
          food: 'Food & Dining',
          transport: 'Transportation',
          accommodation: 'Accommodation',
          entertainment: 'Entertainment',
          other: 'Other'
        };
        return categoryNames[cat] || cat;
      });
      
      this.charts.expenseChart.data.datasets[0].data = amounts;
      this.charts.expenseChart.update();
    }

    // Update monthly trends chart
    if (this.charts.monthlyChart) {
      const monthlyData = stats.byMonth;
      const sortedMonths = Object.keys(monthlyData).sort();
      const monthlyAmounts = sortedMonths.map(month => monthlyData[month]);
      
      const monthLabels = sortedMonths.map(month => {
        const [year, monthNum] = month.split('-');
        const date = new Date(year, monthNum - 1);
        return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      });

      this.charts.monthlyChart.data.labels = monthLabels;
      this.charts.monthlyChart.data.datasets[0].data = monthlyAmounts;
      this.charts.monthlyChart.update();
    }
  }

  exportPDF() {
    // Check if jsPDF is available
    if (typeof window.jsPDF === 'undefined' && typeof window.jspdf === 'undefined') {
      Utils.showToast('PDF library is loading. Please try again in a moment.', 'error');
      return;
    }

    try {
      const user = window.auth.getCurrentUser();
      const expenses = Utils.getFromStorage(`expenses_${user.id}`, []);
      const trips = Utils.getFromStorage(`trips_${user.id}`, []);
      const stats = Utils.calculateStats(expenses);

      // Get jsPDF constructor
      const { jsPDF } = window.jspdf || window.jsPDF || window;
      if (!jsPDF) {
        Utils.showToast('PDF export is not available. Please refresh the page.', 'error');
        return;
      }
      
      const doc = new jsPDF();
      
      // Set up colors
      const primaryColor = [229, 9, 20]; // Netflix red
      const textColor = [51, 51, 51];
      const lightGray = [128, 128, 128];

      // Add header with logo and title
      doc.setFontSize(20);
      doc.setTextColor(...primaryColor);
      doc.text('ExpenseTracker Report', 20, 25);
      
      // Add user info
      doc.setFontSize(12);
      doc.setTextColor(...textColor);
      doc.text(`Generated for: ${user.name}`, 20, 40);
      doc.text(`Email: ${user.email}`, 20, 50);
      doc.text(`Generated on: ${new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })}`, 20, 60);
      
      // Add summary statistics
      doc.setFontSize(14);
      doc.setTextColor(...primaryColor);
      doc.text('Summary', 20, 80);
      
      doc.setFontSize(10);
      doc.setTextColor(...textColor);
      doc.text(`Total Expenses: ${Utils.formatCurrency(stats.total)}`, 20, 95);
      doc.text(`Number of Expenses: ${expenses.length}`, 20, 105);
      doc.text(`Number of Trips: ${trips.length}`, 20, 115);
      doc.text(`Pending Expenses: ${expenses.filter(e => e.status === 'pending').length}`, 120, 95);
      doc.text(`Approved Expenses: ${expenses.filter(e => e.status === 'approved').length}`, 120, 105);

      let yPosition = 135;

      // Add expenses section
      if (expenses.length > 0) {
        doc.setFontSize(14);
        doc.setTextColor(...primaryColor);
        doc.text('Expense Details', 20, yPosition);
        yPosition += 10;
        
        // Prepare table data
        const expenseTableData = expenses.map(expense => [
          expense.title,
          this.formatCategoryForPDF(expense.category),
          Utils.formatCurrency(expense.amount),
          Utils.formatDate(expense.date),
          expense.status.toUpperCase(),
          expense.description ? expense.description.substring(0, 30) + '...' : ''
        ]);
        
        // Add expenses table
        doc.autoTable({
          startY: yPosition,
          head: [['Title', 'Category', 'Amount', 'Date', 'Status', 'Description']],
          body: expenseTableData,
          theme: 'grid',
          headStyles: {
            fillColor: primaryColor,
            textColor: [255, 255, 255],
            fontSize: 10,
            fontStyle: 'bold'
          },
          bodyStyles: {
            fontSize: 9,
            textColor: textColor
          },
          alternateRowStyles: {
            fillColor: [245, 245, 245]
          },
          columnStyles: {
            0: { cellWidth: 35 }, // Title
            1: { cellWidth: 25 }, // Category
            2: { cellWidth: 25 }, // Amount
            3: { cellWidth: 25 }, // Date
            4: { cellWidth: 20 }, // Status
            5: { cellWidth: 40 }  // Description
          },
          margin: { left: 20, right: 20 }
        });

        yPosition = doc.lastAutoTable.finalY + 20;
      }

      // Add trips section
      if (trips.length > 0) {
        // Check if we need a new page
        if (yPosition > 220) {
          doc.addPage();
          yPosition = 30;
        }

        doc.setFontSize(14);
        doc.setTextColor(...primaryColor);
        doc.text('Trip Details', 20, yPosition);
        yPosition += 10;
        
        // Prepare trips table data
        const tripTableData = trips.map(trip => [
          trip.title,
          trip.destination,
          Utils.formatCurrency(trip.budget),
          Utils.formatDate(trip.startDate),
          Utils.formatDate(trip.endDate),
          trip.purpose.toUpperCase(),
          trip.status.toUpperCase()
        ]);
        
        // Add trips table
        doc.autoTable({
          startY: yPosition,
          head: [['Title', 'Destination', 'Budget', 'Start Date', 'End Date', 'Purpose', 'Status']],
          body: tripTableData,
          theme: 'grid',
          headStyles: {
            fillColor: primaryColor,
            textColor: [255, 255, 255],
            fontSize: 10,
            fontStyle: 'bold'
          },
          bodyStyles: {
            fontSize: 9,
            textColor: textColor
          },
          alternateRowStyles: {
            fillColor: [245, 245, 245]
          },
          columnStyles: {
            0: { cellWidth: 30 }, // Title
            1: { cellWidth: 30 }, // Destination
            2: { cellWidth: 25 }, // Budget
            3: { cellWidth: 25 }, // Start Date
            4: { cellWidth: 25 }, // End Date
            5: { cellWidth: 20 }, // Purpose
            6: { cellWidth: 15 }  // Status
          },
          margin: { left: 20, right: 20 }
        });
      }
      
      // Add footer
      const pageCount = doc.internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(...lightGray);
        doc.text(`Page ${i} of ${pageCount}`, 20, doc.internal.pageSize.height - 10);
        doc.text('Generated by ExpenseTracker', doc.internal.pageSize.width - 60, doc.internal.pageSize.height - 10);
      }

      // Save the PDF
      const timestamp = new Date().toISOString().split('T')[0];
      const filename = `ExpenseTracker-Report-${timestamp}.pdf`;
      doc.save(filename);
      
      Utils.showToast('PDF report downloaded successfully!', 'success');

    } catch (error) {
      Utils.handleError(error, 'PDF Export');
      console.error('PDF Export Error:', error);
    }
  }

  formatCategoryForPDF(category) {
    const categoryNames = {
      food: 'Food & Dining',
      transport: 'Transportation',
      accommodation: 'Accommodation',
      entertainment: 'Entertainment',
      other: 'Other'
    };
    return categoryNames[category] || category;
  }

  exportCSV() {
    try {
      const user = window.auth.getCurrentUser();
      const expenses = Utils.getFromStorage(`expenses_${user.id}`, []);
      const trips = Utils.getFromStorage(`trips_${user.id}`, []);

      // Prepare expenses data
      const expenseData = expenses.map(expense => ({
        Type: 'Expense',
        Title: expense.title,
        Amount: expense.amount,
        Category: expense.category,
        Date: expense.date,
        Description: expense.description || '',
        Status: expense.status,
        'Created At': Utils.formatDate(expense.createdAt)
      }));

      // Prepare trips data
      const tripData = trips.map(trip => ({
        Type: 'Trip',
        Title: trip.title,
        Amount: trip.budget,
        Category: 'Trip',
        Date: trip.startDate,
        Description: `${trip.destination} - ${trip.purpose}`,
        Status: trip.status,
        'Created At': Utils.formatDate(trip.createdAt)
      }));

      // Combine data
      const allData = [...expenseData, ...tripData];

      if (allData.length === 0) {
        Utils.showToast('No data to export', 'error');
        return;
      }

      const filename = `expense-data-${new Date().toISOString().split('T')[0]}.csv`;
      Utils.exportToCSV(allData, filename);
      
      Utils.showToast('CSV data downloaded successfully!', 'success');

    } catch (error) {
      Utils.handleError(error, 'CSV Export');
    }
  }

  handleResize() {
    // Update charts on resize
    if (this.charts.expenseChart) {
      this.charts.expenseChart.resize();
    }
    if (this.charts.monthlyChart) {
      this.charts.monthlyChart.resize();
    }

    // Close mobile sidebar on desktop resize
    if (Utils.isDesktop()) {
      this.closeMobileSidebar();
    }
  }

  update() {
    // Update all dashboard data
    this.updateDashboardStats();
    this.updateRecentActivity();
    this.updateCharts();
  }

  // Method to be called when data changes
  onDataChange() {
    const currentSection = this.getCurrentSection();
    this.updateSectionData(currentSection);
    
    // Always update dashboard stats
    if (currentSection !== 'dashboard') {
      this.updateDashboardStats();
    }
  }
}

// Initialize dashboard
window.dashboard = new Dashboard();