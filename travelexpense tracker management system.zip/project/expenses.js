// Expense and Trip management module

class ExpenseManager {
  constructor() {
    this.currentExpenses = [];
    this.currentTrips = [];
    this.init();
  }

  init() {
    this.setupEventListeners();
    this.loadData();
  }

  setupEventListeners() {
    // Expense form submission
    const expenseForm = document.getElementById('expense-form');
    if (expenseForm) {
      expenseForm.addEventListener('submit', (e) => this.handleExpenseSubmit(e));
    }

    // Trip form submission
    const tripForm = document.getElementById('trip-form');
    if (tripForm) {
      tripForm.addEventListener('submit', (e) => this.handleTripSubmit(e));
    }

    // Edit expense form submission
    const editExpenseForm = document.getElementById('edit-expense-form');
    if (editExpenseForm) {
      editExpenseForm.addEventListener('submit', (e) => this.handleEditExpenseSubmit(e));
    }

    // File upload preview
    const expenseBillInput = document.getElementById('expense-bill');
    if (expenseBillInput) {
      expenseBillInput.addEventListener('change', (e) => this.handleFileUpload(e, 'expense-bill-preview'));
    }

    // Set default date to today
    this.setDefaultDates();
  }

  setDefaultDates() {
    const today = new Date().toISOString().split('T')[0];
    
    const expenseDate = document.getElementById('expense-date');
    const tripStartDate = document.getElementById('trip-start-date');
    const tripEndDate = document.getElementById('trip-end-date');
    
    if (expenseDate && !expenseDate.value) {
      expenseDate.value = today;
    }
    
    if (tripStartDate && !tripStartDate.value) {
      tripStartDate.value = today;
    }
    
    if (tripEndDate && !tripEndDate.value) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tripEndDate.value = tomorrow.toISOString().split('T')[0];
    }
  }

  async handleFileUpload(event, previewElementId) {
    const file = event.target.files[0];
    const previewElement = document.getElementById(previewElementId);
    
    if (!previewElement) return;

    if (file) {
      try {
        // Validate file type
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'application/pdf'];
        if (!allowedTypes.includes(file.type)) {
          Utils.showToast('Please upload only image files (JPG, PNG, GIF) or PDF files.', 'error');
          event.target.value = '';
          return;
        }

        // Validate file size (5MB limit)
        const maxSize = 5 * 1024 * 1024; // 5MB
        if (file.size > maxSize) {
          Utils.showToast('File size must be less than 5MB.', 'error');
          event.target.value = '';
          return;
        }

        // Show file preview
        const dataURL = await Utils.readFileAsDataURL(file);
        
        if (file.type === 'application/pdf') {
          previewElement.innerHTML = `
            <div class="file-info">
              <i class="fas fa-file-pdf" style="font-size: 2rem; color: #dc2626;"></i>
              <div>
                <p><strong>${file.name}</strong></p>
                <p>${Utils.formatFileSize(file.size)}</p>
              </div>
            </div>
          `;
        } else {
          previewElement.innerHTML = `
            <img src="${dataURL}" alt="Bill preview" style="max-width: 100%; max-height: 150px; border-radius: 8px;">
            <p style="margin-top: 0.5rem; font-size: 0.9rem; color: var(--text-secondary);">
              ${file.name} (${Utils.formatFileSize(file.size)})
            </p>
          `;
        }

      } catch (error) {
        Utils.handleError(error, 'File Upload');
        event.target.value = '';
      }
    } else {
      previewElement.innerHTML = '';
    }
  }

  async handleExpenseSubmit(event) {
    event.preventDefault();
    
    const title = document.getElementById('expense-title').value.trim();
    const amount = parseFloat(document.getElementById('expense-amount').value);
    const category = document.getElementById('expense-category').value;
    const date = document.getElementById('expense-date').value;
    const description = document.getElementById('expense-description').value.trim();
    const billFile = document.getElementById('expense-bill').files[0];

    // Validate form data
    if (!this.validateExpenseData(title, amount, category, date)) {
      return;
    }

    try {
      // Handle file upload
      let billData = null;
      if (billFile) {
        billData = {
          name: billFile.name,
          size: billFile.size,
          type: billFile.type,
          data: await Utils.readFileAsDataURL(billFile)
        };
      }

      // Create expense object
      const expense = {
        id: Utils.generateId(),
        title,
        amount,
        category,
        date,
        description,
        bill: billData,
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      // Save expense
      this.addExpense(expense);
      
      // Close modal and reset form
      Utils.closeModal('expense-modal');
      Utils.resetForm('expense-form');
      
      // Show success message
      Utils.showToast('Expense added successfully!', 'success');
      
      // Update displays
      this.renderExpenses();
      window.dashboard?.onDataChange();

    } catch (error) {
      Utils.handleError(error, 'Add Expense');
    }
  }

  async handleTripSubmit(event) {
    event.preventDefault();
    
    const title = document.getElementById('trip-title').value.trim();
    const destination = document.getElementById('trip-destination').value.trim();
    const startDate = document.getElementById('trip-start-date').value;
    const endDate = document.getElementById('trip-end-date').value;
    const budget = parseFloat(document.getElementById('trip-budget').value);
    const purpose = document.getElementById('trip-purpose').value;
    const description = document.getElementById('trip-description').value.trim();

    // Validate form data
    if (!this.validateTripData(title, destination, startDate, endDate, budget, purpose)) {
      return;
    }

    try {
      // Create trip object
      const trip = {
        id: Utils.generateId(),
        title,
        destination,
        startDate,
        endDate,
        budget,
        purpose,
        description,
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      // Save trip
      this.addTrip(trip);
      
      // Close modal and reset form
      Utils.closeModal('trip-modal');
      Utils.resetForm('trip-form');
      
      // Show success message
      Utils.showToast('Trip added successfully!', 'success');
      
      // Update displays
      this.renderTrips();
      window.dashboard?.onDataChange();

    } catch (error) {
      Utils.handleError(error, 'Add Trip');
    }
  }

  async handleEditExpenseSubmit(event) {
    event.preventDefault();
    
    const id = document.getElementById('edit-expense-id').value;
    const title = document.getElementById('edit-expense-title').value.trim();
    const amount = parseFloat(document.getElementById('edit-expense-amount').value);
    const category = document.getElementById('edit-expense-category').value;
    const date = document.getElementById('edit-expense-date').value;
    const description = document.getElementById('edit-expense-description').value.trim();

    // Validate form data
    if (!this.validateExpenseData(title, amount, category, date)) {
      return;
    }

    try {
      // Update expense
      this.updateExpense(id, { title, amount, category, date, description });
      
      // Close modal and reset form
      Utils.closeModal('edit-expense-modal');
      Utils.resetForm('edit-expense-form');
      
      // Show success message
      Utils.showToast('Expense updated successfully!', 'success');
      
      // Update displays
      this.renderExpenses();
      window.dashboard?.onDataChange();

    } catch (error) {
      Utils.handleError(error, 'Update Expense');
    }
  }

  validateExpenseData(title, amount, category, date) {
    if (!Utils.validateRequired(title)) {
      Utils.showToast('Please enter an expense title.', 'error');
      return false;
    }

    if (!Utils.validateNumber(amount, 0.01)) {
      Utils.showToast('Please enter a valid amount greater than $0.', 'error');
      return false;
    }

    if (!Utils.validateRequired(category)) {
      Utils.showToast('Please select a category.', 'error');
      return false;
    }

    if (!Utils.validateDate(date)) {
      Utils.showToast('Please enter a valid date.', 'error');
      return false;
    }

    return true;
  }

  validateTripData(title, destination, startDate, endDate, budget, purpose) {
    if (!Utils.validateRequired(title)) {
      Utils.showToast('Please enter a trip title.', 'error');
      return false;
    }

    if (!Utils.validateRequired(destination)) {
      Utils.showToast('Please enter a destination.', 'error');
      return false;
    }

    if (!Utils.validateDate(startDate)) {
      Utils.showToast('Please enter a valid start date.', 'error');
      return false;
    }

    if (!Utils.validateDate(endDate)) {
      Utils.showToast('Please enter a valid end date.', 'error');
      return false;
    }

    if (new Date(endDate) < new Date(startDate)) {
      Utils.showToast('End date must be after start date.', 'error');
      return false;
    }

    if (!Utils.validateNumber(budget, 0.01)) {
      Utils.showToast('Please enter a valid budget greater than $0.', 'error');
      return false;
    }

    if (!Utils.validateRequired(purpose)) {
      Utils.showToast('Please select a purpose.', 'error');
      return false;
    }

    return true;
  }

  loadData() {
    if (!window.auth?.isAuthenticated()) return;

    const user = window.auth.getCurrentUser();
    this.currentExpenses = Utils.getFromStorage(`expenses_${user.id}`, []);
    this.currentTrips = Utils.getFromStorage(`trips_${user.id}`, []);
  }

  saveExpenses() {
    if (!window.auth?.isAuthenticated()) return;

    const user = window.auth.getCurrentUser();
    Utils.saveToStorage(`expenses_${user.id}`, this.currentExpenses);
  }

  saveTrips() {
    if (!window.auth?.isAuthenticated()) return;

    const user = window.auth.getCurrentUser();
    Utils.saveToStorage(`trips_${user.id}`, this.currentTrips);
  }

  addExpense(expense) {
    this.currentExpenses.unshift(expense); // Add to beginning
    this.saveExpenses();
  }

  addTrip(trip) {
    this.currentTrips.unshift(trip); // Add to beginning
    this.saveTrips();
  }

  updateExpense(id, updates) {
    const index = this.currentExpenses.findIndex(expense => expense.id === id);
    if (index !== -1) {
      this.currentExpenses[index] = { ...this.currentExpenses[index], ...updates };
      this.saveExpenses();
    }
  }

  updateTrip(id, updates) {
    const index = this.currentTrips.findIndex(trip => trip.id === id);
    if (index !== -1) {
      this.currentTrips[index] = { ...this.currentTrips[index], ...updates };
      this.saveTrips();
    }
  }

  deleteExpense(id) {
    this.currentExpenses = this.currentExpenses.filter(expense => expense.id !== id);
    this.saveExpenses();
  }

  deleteTrip(id) {
    this.currentTrips = this.currentTrips.filter(trip => trip.id !== id);
    this.saveTrips();
  }

  approveExpense(id) {
    this.updateExpense(id, { status: 'approved' });
    Utils.showToast('Expense approved successfully!', 'success');
    this.renderExpenses();
    window.dashboard?.onDataChange();
  }

  approveTrip(id) {
    this.updateTrip(id, { status: 'approved' });
    Utils.showToast('Trip approved successfully!', 'success');
    this.renderTrips();
    window.dashboard?.onDataChange();
  }

  editExpense(id) {
    const expense = this.currentExpenses.find(e => e.id === id);
    if (!expense) return;

    // Populate edit form
    document.getElementById('edit-expense-id').value = expense.id;
    document.getElementById('edit-expense-title').value = expense.title;
    document.getElementById('edit-expense-amount').value = expense.amount;
    document.getElementById('edit-expense-category').value = expense.category;
    document.getElementById('edit-expense-date').value = expense.date;
    document.getElementById('edit-expense-description').value = expense.description || '';

    // Open edit modal
    Utils.openModal('edit-expense-modal');
  }

  renderExpenses() {
    const container = document.getElementById('expenses-list');
    if (!container) return;

    const filtered = this.getFilteredExpenses();
    
    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-receipt"></i>
          <h3>No expenses found</h3>
          <p>Add your first expense to get started!</p>
          <button class="primary-btn" onclick="Utils.openModal('expense-modal')">
            <i class="fas fa-plus"></i>
            Add Expense
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map(expense => this.createExpenseCard(expense)).join('');
  }

  renderTrips() {
    const container = document.getElementById('trips-list');
    if (!container) return;

    const filtered = this.getFilteredTrips();
    
    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-plane"></i>
          <h3>No trips found</h3>
          <p>Plan your first trip to get started!</p>
          <button class="primary-btn" onclick="Utils.openModal('trip-modal')">
            <i class="fas fa-plus"></i>
            Add Trip
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map(trip => this.createTripCard(trip)).join('');
  }

  createExpenseCard(expense) {
    const categoryIcon = Utils.getCategoryIcon(expense.category);
    const categoryColor = Utils.getCategoryColor(expense.category);
    
    return `
      <div class="item-card expense-card" data-id="${expense.id}">
        <div class="item-header">
          <div class="item-title">
            <i class="${categoryIcon}" style="color: ${categoryColor}; margin-right: 0.5rem;"></i>
            ${expense.title}
          </div>
          <div class="item-meta">
            <span class="item-amount">${Utils.formatCurrency(expense.amount)}</span>
            <span class="item-date">${Utils.formatDate(expense.date)}</span>
          </div>
        </div>
        
        <div class="item-body">
          ${expense.description ? `<div class="item-description">${expense.description}</div>` : ''}
          
          ${expense.bill ? `
            <div class="item-bill">
              ${expense.bill.type === 'application/pdf' ? `
                <div class="bill-pdf">
                  <i class="fas fa-file-pdf" style="color: #dc2626; margin-right: 0.5rem;"></i>
                  <span>${expense.bill.name}</span>
                </div>
              ` : `
                <img src="${expense.bill.data}" alt="Bill" class="bill-preview">
              `}
            </div>
          ` : ''}
        </div>
        
        <div class="item-footer">
          <div class="item-status status-${expense.status}">
            ${expense.status}
          </div>
          
          <div class="item-actions">
            ${expense.status === 'pending' ? `
              <button class="action-btn approve" onclick="window.expenseManager.approveExpense('${expense.id}')" title="Approve">
                <i class="fas fa-check"></i>
              </button>
            ` : ''}
            <button class="action-btn edit" onclick="window.expenseManager.editExpense('${expense.id}')" title="Edit">
              <i class="fas fa-edit"></i>
            </button>
            <button class="action-btn delete" onclick="window.expenseManager.confirmDeleteExpense('${expense.id}')" title="Delete">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }

  createTripCard(trip) {
    const duration = this.calculateTripDuration(trip.startDate, trip.endDate);
    
    return `
      <div class="item-card trip-card" data-id="${trip.id}">
        <div class="item-header">
          <div class="item-title">
            <i class="fas fa-plane" style="color: #4ecdc4; margin-right: 0.5rem;"></i>
            ${trip.title}
          </div>
          <div class="item-meta">
            <span class="item-amount">${Utils.formatCurrency(trip.budget)}</span>
            <span class="item-destination">${trip.destination}</span>
          </div>
        </div>
        
        <div class="item-body">
          <div class="trip-dates">
            <div class="trip-date-item">
              <i class="fas fa-calendar-alt"></i>
              <span>${Utils.formatDate(trip.startDate)} - ${Utils.formatDate(trip.endDate)}</span>
            </div>
            <div class="trip-duration">
              <i class="fas fa-clock"></i>
              <span>${duration}</span>
            </div>
            <div class="trip-purpose">
              <i class="fas fa-tag"></i>
              <span>${this.formatPurpose(trip.purpose)}</span>
            </div>
          </div>
          
          ${trip.description ? `<div class="item-description">${trip.description}</div>` : ''}
        </div>
        
        <div class="item-footer">
          <div class="item-status status-${trip.status}">
            ${trip.status}
          </div>
          
          <div class="item-actions">
            ${trip.status === 'pending' ? `
              <button class="action-btn approve" onclick="window.expenseManager.approveTrip('${trip.id}')" title="Approve">
                <i class="fas fa-check"></i>
              </button>
            ` : ''}
            <button class="action-btn delete" onclick="window.expenseManager.confirmDeleteTrip('${trip.id}')" title="Delete">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }

  calculateTripDuration(startDate, endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return '1 day';
    if (diffDays === 1) return '1 day';
    return `${diffDays} days`;
  }

  formatPurpose(purpose) {
    const purposes = {
      business: 'Business',
      personal: 'Personal',
      conference: 'Conference',
      training: 'Training'
    };
    return purposes[purpose] || purpose;
  }

  getFilteredExpenses() {
    const statusFilter = document.getElementById('expense-filter')?.value || 'all';
    const categoryFilter = document.getElementById('category-filter')?.value || 'all';
    
    return Utils.filterItems(this.currentExpenses, {
      status: statusFilter,
      category: categoryFilter
    });
  }

  getFilteredTrips() {
    const statusFilter = document.getElementById('trip-filter')?.value || 'all';
    
    return Utils.filterItems(this.currentTrips, {
      status: statusFilter
    });
  }

  filterExpenses() {
    this.renderExpenses();
  }

  filterTrips() {
    this.renderTrips();
  }

  confirmDeleteExpense(id) {
    const expense = this.currentExpenses.find(e => e.id === id);
    if (!expense) return;

    if (confirm(`Are you sure you want to delete "${expense.title}"? This action cannot be undone.`)) {
      this.deleteExpense(id);
      this.renderExpenses();
      window.dashboard?.onDataChange();
      Utils.showToast('Expense deleted successfully.', 'success');
    }
  }

  confirmDeleteTrip(id) {
    const trip = this.currentTrips.find(t => t.id === id);
    if (!trip) return;

    if (confirm(`Are you sure you want to delete "${trip.title}"? This action cannot be undone.`)) {
      this.deleteTrip(id);
      this.renderTrips();
      window.dashboard?.onDataChange();
      Utils.showToast('Trip deleted successfully.', 'success');
    }
  }

  clear() {
    // Clear data when user logs out
    this.currentExpenses = [];
    this.currentTrips = [];
  }
}

// Initialize expense manager
window.expenseManager = new ExpenseManager();