// Authentication module for Expense Tracker

class Auth {
  constructor() {
    this.currentUser = null;
    this.init();
  }

  init() {
    // Check if user is already logged in
    this.currentUser = Utils.getFromStorage('currentUser');
    
    // Set up event listeners
    this.setupEventListeners();
    
    // Initialize UI based on auth state
    this.updateUI();
  }

  setupEventListeners() {
    // Toggle between login and signup forms
    const showSignupBtn = document.getElementById('show-signup');
    const showLoginBtn = document.getElementById('show-login');
    
    if (showSignupBtn) {
      showSignupBtn.addEventListener('click', () => this.toggleAuthForm('signup'));
    }
    
    if (showLoginBtn) {
      showLoginBtn.addEventListener('click', () => this.toggleAuthForm('login'));
    }

    // Form submissions
    const loginForm = document.querySelector('#login-form form');
    const signupForm = document.querySelector('#signup-form form');
    
    if (loginForm) {
      loginForm.addEventListener('submit', (e) => this.handleLogin(e));
    }
    
    if (signupForm) {
      signupForm.addEventListener('submit', (e) => this.handleSignup(e));
    }

    // Password toggle functionality
    const passwordToggles = document.querySelectorAll('.toggle-password');
    passwordToggles.forEach(toggle => {
      toggle.addEventListener('click', (e) => this.togglePassword(e));
    });

    // Logout functionality
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => this.logout());
    }
  }

  toggleAuthForm(formType) {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    
    if (formType === 'signup') {
      loginForm.classList.remove('active');
      signupForm.classList.add('active');
      Utils.animateElement(signupForm, 'slide-in-right');
    } else {
      signupForm.classList.remove('active');
      loginForm.classList.add('active');
      Utils.animateElement(loginForm, 'slide-in-left');
    }
  }

  togglePassword(event) {
    const button = event.currentTarget;
    const input = button.parentElement.querySelector('input');
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
      input.type = 'text';
      icon.classList.remove('fa-eye');
      icon.classList.add('fa-eye-slash');
    } else {
      input.type = 'password';
      icon.classList.remove('fa-eye-slash');
      icon.classList.add('fa-eye');
    }
  }

  async handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    
    // Validate inputs
    if (!this.validateLoginData(email, password)) {
      return;
    }

    // Show loading state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Signing in...';
    submitBtn.disabled = true;

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user exists in our "database" (localStorage)
      const users = Utils.getFromStorage('users', []);
      const user = users.find(u => u.email === email && u.password === password);
      
      if (user) {
        // Successful login
        this.currentUser = {
          id: user.id,
          name: user.name,
          email: user.email,
          avatar: user.avatar || 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150&h=150'
        };
        
        Utils.saveToStorage('currentUser', this.currentUser);
        Utils.showToast('Welcome back! Login successful.', 'success');
        
        // Update UI
        this.updateUI();
        
        // Initialize demo data if this is first login
        this.initializeDemoData();
        
      } else {
        // Login failed
        Utils.showToast('Invalid email or password. Please try again.', 'error');
      }
      
    } catch (error) {
      Utils.handleError(error, 'Login');
    } finally {
      // Reset button state
      submitBtn.textContent = originalText;
      submitBtn.disabled = false;
    }
  }

  async handleSignup(event) {
    event.preventDefault();
    
    const name = document.getElementById('signup-name').value.trim();
    const email = document.getElementById('signup-email').value.trim();
    const password = document.getElementById('signup-password').value;
    
    // Validate inputs
    if (!this.validateSignupData(name, email, password)) {
      return;
    }

    // Show loading state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Creating account...';
    submitBtn.disabled = true;

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user already exists
      const users = Utils.getFromStorage('users', []);
      const existingUser = users.find(u => u.email === email);
      
      if (existingUser) {
        Utils.showToast('An account with this email already exists.', 'error');
        return;
      }

      // Create new user
      const newUser = {
        id: Utils.generateId(),
        name,
        email,
        password, // In a real app, this would be hashed
        createdAt: new Date().toISOString(),
        avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150&h=150'
      };
      
      // Save to "database"
      users.push(newUser);
      Utils.saveToStorage('users', users);
      
      // Log in the new user
      this.currentUser = {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        avatar: newUser.avatar
      };
      
      Utils.saveToStorage('currentUser', this.currentUser);
      Utils.showToast('Account created successfully! Welcome to ExpenseTracker.', 'success');
      
      // Update UI
      this.updateUI();
      
      // Initialize demo data for new user
      this.initializeDemoData();
      
    } catch (error) {
      Utils.handleError(error, 'Signup');
    } finally {
      // Reset button state
      submitBtn.textContent = originalText;
      submitBtn.disabled = false;
    }
  }

  validateLoginData(email, password) {
    if (!email) {
      Utils.showToast('Please enter your email address.', 'error');
      document.getElementById('login-email').focus();
      return false;
    }
    
    if (!Utils.validateEmail(email)) {
      Utils.showToast('Please enter a valid email address.', 'error');
      document.getElementById('login-email').focus();
      return false;
    }
    
    if (!password) {
      Utils.showToast('Please enter your password.', 'error');
      document.getElementById('login-password').focus();
      return false;
    }
    
    if (password.length < 6) {
      Utils.showToast('Password must be at least 6 characters long.', 'error');
      document.getElementById('login-password').focus();
      return false;
    }
    
    return true;
  }

  validateSignupData(name, email, password) {
    if (!name) {
      Utils.showToast('Please enter your full name.', 'error');
      document.getElementById('signup-name').focus();
      return false;
    }
    
    if (name.length < 2) {
      Utils.showToast('Name must be at least 2 characters long.', 'error');
      document.getElementById('signup-name').focus();
      return false;
    }
    
    if (!email) {
      Utils.showToast('Please enter your email address.', 'error');
      document.getElementById('signup-email').focus();
      return false;
    }
    
    if (!Utils.validateEmail(email)) {
      Utils.showToast('Please enter a valid email address.', 'error');
      document.getElementById('signup-email').focus();
      return false;
    }
    
    if (!password) {
      Utils.showToast('Please enter a password.', 'error');
      document.getElementById('signup-password').focus();
      return false;
    }
    
    if (password.length < 6) {
      Utils.showToast('Password must be at least 6 characters long.', 'error');
      document.getElementById('signup-password').focus();
      return false;
    }
    
    return true;
  }

  updateUI() {
    const authSection = document.getElementById('auth-section');
    const dashboardSection = document.getElementById('dashboard-section');
    
    if (this.currentUser) {
      // User is logged in - show dashboard
      if (authSection) authSection.classList.add('hidden');
      if (dashboardSection) dashboardSection.classList.remove('hidden');
      
      // Update user info in dashboard
      this.updateUserInfo();
      
    } else {
      // User is not logged in - show auth
      if (authSection) authSection.classList.remove('hidden');
      if (dashboardSection) dashboardSection.classList.add('hidden');
    }
  }

  updateUserInfo() {
    if (!this.currentUser) return;
    
    // Update user name displays
    const userNameElements = document.querySelectorAll('#user-name, #welcome-name');
    userNameElements.forEach(element => {
      if (element.id === 'welcome-name') {
        element.textContent = this.currentUser.name.split(' ')[0]; // First name only
      } else {
        element.textContent = this.currentUser.name;
      }
    });
    
    // Update user avatar
    const avatarElements = document.querySelectorAll('.user-avatar');
    avatarElements.forEach(element => {
      element.src = this.currentUser.avatar;
      element.alt = this.currentUser.name;
    });
    
    // Update profile dropdown
    window.dashboard?.updateProfileDropdown();
  }

  logout() {
    // Clear user data
    this.currentUser = null;
    Utils.removeFromStorage('currentUser');
    
    // Reset forms
    Utils.resetForm('login-form');
    Utils.resetForm('signup-form');
    
    // Show login form
    this.toggleAuthForm('login');
    
    // Update UI
    this.updateUI();
    
    Utils.showToast('You have been logged out successfully.', 'success');
    
    // Clear any sensitive data from memory
    window.expenseManager?.clear();
  }

  initializeDemoData() {
    // Check if user already has data
    const existingExpenses = Utils.getFromStorage(`expenses_${this.currentUser.id}`, []);
    const existingTrips = Utils.getFromStorage(`trips_${this.currentUser.id}`, []);
    
    if (existingExpenses.length === 0 && existingTrips.length === 0) {
      // Initialize with demo data
      this.createDemoExpenses();
      this.createDemoTrips();
      Utils.showToast('Demo data has been added to help you get started!', 'success');
    }
  }

  createDemoExpenses() {
    const demoExpenses = [
      {
        id: Utils.generateId(),
        title: 'Airport Taxi',
        amount: 45.50,
        category: 'transport',
        date: '2024-01-15',
        description: 'Taxi from airport to hotel',
        status: 'approved',
        createdAt: new Date().toISOString()
      },
      {
        id: Utils.generateId(),
        title: 'Business Lunch',
        amount: 78.90,
        category: 'food',
        date: '2024-01-16',
        description: 'Lunch meeting with client',
        status: 'pending',
        createdAt: new Date().toISOString()
      },
      {
        id: Utils.generateId(),
        title: 'Hotel Stay',
        amount: 234.00,
        category: 'accommodation',
        date: '2024-01-15',
        description: '2 nights at downtown hotel',
        status: 'approved',
        createdAt: new Date().toISOString()
      },
      {
        id: Utils.generateId(),
        title: 'Conference Tickets',
        amount: 89.99,
        category: 'entertainment',
        date: '2024-01-17',
        description: 'Tech conference admission',
        status: 'pending',
        createdAt: new Date().toISOString()
      },
      {
        id: Utils.generateId(),
        title: 'Office Supplies',
        amount: 23.45,
        category: 'other',
        date: '2024-01-18',
        description: 'Notebooks and pens',
        status: 'approved',
        createdAt: new Date().toISOString()
      }
    ];

    Utils.saveToStorage(`expenses_${this.currentUser.id}`, demoExpenses);
  }

  createDemoTrips() {
    const demoTrips = [
      {
        id: Utils.generateId(),
        title: 'New York Business Trip',
        destination: 'New York, NY',
        startDate: '2024-01-15',
        endDate: '2024-01-18',
        budget: 1500.00,
        purpose: 'business',
        description: 'Quarterly business review meeting',
        status: 'approved',
        createdAt: new Date().toISOString()
      },
      {
        id: Utils.generateId(),
        title: 'San Francisco Conference',
        destination: 'San Francisco, CA',
        startDate: '2024-02-10',
        endDate: '2024-02-13',
        budget: 2000.00,
        purpose: 'conference',
        description: 'Annual tech conference',
        status: 'pending',
        createdAt: new Date().toISOString()
      }
    ];

    Utils.saveToStorage(`trips_${this.currentUser.id}`, demoTrips);
  }

  // Get current user
  getCurrentUser() {
    return this.currentUser;
  }

  // Check if user is authenticated
  isAuthenticated() {
    return !!this.currentUser;
  }

  // Get user-specific storage key
  getUserStorageKey(key) {
    if (!this.currentUser) return null;
    return `${key}_${this.currentUser.id}`;
  }
}

// Initialize auth system
window.auth = new Auth();