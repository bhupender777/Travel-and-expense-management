// Utility functions for the Expense Tracker application

class Utils {
  // Format currency with proper formatting
  static formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  }

  // Format date to readable string
  static formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  // Format date for input fields
  static formatDateForInput(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toISOString().split('T')[0];
  }

  // Generate unique ID
  static generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  // Debounce function for search/filter
  static debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Show toast notification
  static showToast(message, type = 'success') {
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
      existingToast.remove();
    }

    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <div class="toast-content">
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
      </div>
    `;

    // Add toast styles
    toast.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${type === 'success' ? '#46d369' : type === 'error' ? '#dc2626' : '#3b82f6'};
      color: white;
      padding: 1rem 1.5rem;
      border-radius: 8px;
      z-index: 10000;
      transform: translateX(400px);
      transition: transform 0.3s ease;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
    `;

    // Add to document
    document.body.appendChild(toast);

    // Animate in
    setTimeout(() => {
      toast.style.transform = 'translateX(0)';
    }, 100);

    // Remove after delay
    setTimeout(() => {
      toast.style.transform = 'translateX(400px)';
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3000);
  }

  // Local storage helpers
  static saveToStorage(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (error) {
      console.error('Error saving to localStorage:', error);
      return false;
    }
  }

  static getFromStorage(key, defaultValue = null) {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return defaultValue;
    }
  }

  static removeFromStorage(key) {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error('Error removing from localStorage:', error);
      return false;
    }
  }

  // File handling utilities
  static readFileAsDataURL(file) {
    return new Promise((resolve, reject) => {
      if (!file) {
        resolve(null);
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(file);
    });
  }

  static formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  // Category helpers
  static getCategoryIcon(category) {
    const icons = {
      food: 'fas fa-utensils',
      transport: 'fas fa-car',
      accommodation: 'fas fa-bed',
      entertainment: 'fas fa-film',
      other: 'fas fa-ellipsis-h'
    };
    return icons[category] || icons.other;
  }

  static getCategoryColor(category) {
    const colors = {
      food: '#ff6b6b',
      transport: '#4ecdc4',
      accommodation: '#45b7d1',
      entertainment: '#96ceb4',
      other: '#ffeaa7'
    };
    return colors[category] || colors.other;
  }

  // Validation helpers
  static validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  static validateRequired(value) {
    return value && value.toString().trim().length > 0;
  }

  static validateNumber(value, min = 0) {
    const num = parseFloat(value);
    return !isNaN(num) && num >= min;
  }

  static validateDate(date) {
    const d = new Date(date);
    return d instanceof Date && !isNaN(d);
  }

  // Export utilities
  static exportToCSV(data, filename) {
    if (!data || data.length === 0) {
      Utils.showToast('No data to export', 'error');
      return;
    }

    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header];
          // Escape commas and quotes
          if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
            return `"${value.replace(/"/g, '""')}"`;
          }
          return value;
        }).join(',')
      )
    ].join('\n');

    Utils.downloadFile(csvContent, filename, 'text/csv');
  }

  static downloadFile(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = window.URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    window.URL.revokeObjectURL(url);
  }

  // Animation helpers
  static animateElement(element, animationClass) {
    if (!element) return;
    
    element.classList.add(animationClass);
    
    // Remove animation class after completion
    element.addEventListener('animationend', () => {
      element.classList.remove(animationClass);
    }, { once: true });
  }

  // Modal helpers
  static openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
      
      // Focus first input
      const firstInput = modal.querySelector('input, select, textarea');
      if (firstInput) {
        setTimeout(() => firstInput.focus(), 100);
      }
    }
  }

  static closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  // Form helpers
  static resetForm(formId) {
    const form = document.getElementById(formId);
    if (form) {
      form.reset();
      
      // Clear any file previews
      const previews = form.querySelectorAll('.file-preview');
      previews.forEach(preview => {
        preview.innerHTML = '';
      });
      
      // Reset any hidden inputs
      const hiddenInputs = form.querySelectorAll('input[type="hidden"]');
      hiddenInputs.forEach(input => {
        input.value = '';
      });
    }
  }

  // Search and filter helpers
  static filterItems(items, filters) {
    return items.filter(item => {
      for (const [key, value] of Object.entries(filters)) {
        if (value && value !== 'all') {
          if (key === 'search') {
            const searchTerm = value.toLowerCase();
            const searchableText = `${item.title} ${item.description || ''} ${item.category || ''}`.toLowerCase();
            if (!searchableText.includes(searchTerm)) {
              return false;
            }
          } else if (item[key] !== value) {
            return false;
          }
        }
      }
      return true;
    });
  }

  // Statistics helpers
  static calculateStats(expenses) {
    const stats = {
      total: 0,
      byCategory: {},
      byStatus: { pending: 0, approved: 0 },
      byMonth: {}
    };

    expenses.forEach(expense => {
      const amount = parseFloat(expense.amount) || 0;
      stats.total += amount;

      // By category
      const category = expense.category || 'other';
      stats.byCategory[category] = (stats.byCategory[category] || 0) + amount;

      // By status
      const status = expense.status || 'pending';
      stats.byStatus[status] += amount;

      // By month
      const date = new Date(expense.date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      stats.byMonth[monthKey] = (stats.byMonth[monthKey] || 0) + amount;
    });

    return stats;
  }

  // Theme helpers
  static setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    Utils.saveToStorage('theme', theme);
  }

  static getTheme() {
    return Utils.getFromStorage('theme', 'dark');
  }

  static toggleTheme() {
    const currentTheme = Utils.getTheme();
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    Utils.setTheme(newTheme);
    return newTheme;
  }

  // Loading helpers
  static showLoading() {
    const loader = document.getElementById('loading-screen');
    if (loader) {
      loader.style.display = 'flex';
    }
  }

  static hideLoading() {
    const loader = document.getElementById('loading-screen');
    if (loader) {
      loader.style.display = 'none';
    }
  }

  // Device detection
  static isMobile() {
    return window.innerWidth <= 768;
  }

  static isTablet() {
    return window.innerWidth > 768 && window.innerWidth <= 1024;
  }

  static isDesktop() {
    return window.innerWidth > 1024;
  }

  // Error handling
  static handleError(error, context = 'Unknown') {
    console.error(`Error in ${context}:`, error);
    Utils.showToast(`An error occurred: ${error.message || 'Unknown error'}`, 'error');
  }

  // Performance helpers
  static throttle(func, limit) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }

  // Accessibility helpers
  static announceToScreenReader(message) {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.style.position = 'absolute';
    announcement.style.left = '-10000px';
    announcement.style.width = '1px';
    announcement.style.height = '1px';
    announcement.style.overflow = 'hidden';
    announcement.textContent = message;
    
    document.body.appendChild(announcement);
    
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 1000);
  }
}

// Export for use in other modules
window.Utils = Utils;