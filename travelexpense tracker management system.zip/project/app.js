// Main application initialization and coordination

class App {
  constructor() {
    this.isLoaded = false;
    this.init();
  }

  async init() {
    try {
      // Show loading screen
      Utils.showLoading();
      
      // Initialize theme
      this.initializeTheme();
      
      // Wait for DOM to be fully loaded
      if (document.readyState === 'loading') {
        await new Promise(resolve => {
          document.addEventListener('DOMContentLoaded', resolve);
        });
      }

      // Initialize all modules in sequence
      await this.initializeModules();
      
      // Set up global event listeners
      this.setupGlobalEventListeners();
      
      // Simulate loading time for smooth UX
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Hide loading screen
      Utils.hideLoading();
      
      // Mark as loaded
      this.isLoaded = true;
      
      console.log('🚀 ExpenseTracker app initialized successfully!');
      
    } catch (error) {
      Utils.handleError(error, 'App Initialization');
      Utils.hideLoading();
    }
  }

  initializeTheme() {
    // Apply saved theme or default to dark
    const savedTheme = Utils.getTheme();
    Utils.setTheme(savedTheme);
    
    // Update theme toggle button
    const themeToggle = document.getElementById('theme-toggle');
    const themeIcon = themeToggle?.querySelector('i');
    const themeText = themeToggle?.querySelector('span');
    
    if (themeIcon && themeText) {
      if (savedTheme === 'light') {
        themeIcon.className = 'fas fa-sun';
        themeText.textContent = 'Light Mode';
      } else {
        themeIcon.className = 'fas fa-moon';
        themeText.textContent = 'Dark Mode';
      }
    }
  }

  async initializeModules() {
    // Modules are already initialized via their script tags
    // We just need to ensure they're ready and configured
    
    // Restore sidebar state
    const sidebarCollapsed = Utils.getFromStorage('sidebarCollapsed', false);
    const sidebar = document.getElementById('sidebar');
    if (sidebar && sidebarCollapsed) {
      sidebar.classList.add('collapsed');
    }
    
    // Load user data if authenticated
    if (window.auth?.isAuthenticated()) {
      window.expenseManager?.loadData();
      window.dashboard?.update();
    }
  }

  setupGlobalEventListeners() {
    // Global keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      this.handleGlobalKeyboard(e);
    });

    // Global click handler for dynamic elements
    document.addEventListener('click', (e) => {
      this.handleGlobalClick(e);
    });

    // Handle browser back/forward
    window.addEventListener('popstate', (e) => {
      // Handle navigation state if needed
    });

    // Handle online/offline status
    window.addEventListener('online', () => {
      Utils.showToast('Connection restored', 'success');
    });

    window.addEventListener('offline', () => {
      Utils.showToast('You are now offline', 'warning');
    });

    // Handle visibility change (tab focus/blur)
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && this.isLoaded) {
        // Refresh data when tab becomes visible
        this.refreshData();
      }
    });

    // Handle unload (save any pending data)
    window.addEventListener('beforeunload', (e) => {
      // Auto-save any form data or pending changes
      this.handleBeforeUnload(e);
    });
  }

  handleGlobalKeyboard(event) {
    // Only handle shortcuts when not typing in inputs
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
      return;
    }

    // Keyboard shortcuts
    if (event.ctrlKey || event.metaKey) {
      switch (event.key) {
        case 'n':
          event.preventDefault();
          if (event.shiftKey) {
            // Ctrl+Shift+N: Add Trip
            Utils.openModal('trip-modal');
          } else {
            // Ctrl+N: Add Expense
            Utils.openModal('expense-modal');
          }
          break;
        
        case 'd':
          event.preventDefault();
          // Ctrl+D: Go to Dashboard
          window.dashboard?.switchSection('dashboard');
          break;
        
        case 'e':
          event.preventDefault();
          // Ctrl+E: Go to Expenses
          window.dashboard?.switchSection('expenses');
          break;
        
        case 't':
          event.preventDefault();
          // Ctrl+T: Go to Trips
          window.dashboard?.switchSection('trips');
          break;
        
        case 'a':
          event.preventDefault();
          // Ctrl+A: Go to Analytics
          window.dashboard?.switchSection('analytics');
          break;
        
        case 'r':
          event.preventDefault();
          // Ctrl+R: Go to Reports (override default refresh)
          window.dashboard?.switchSection('reports');
          break;
      }
    }

    // Escape key to close modals
    if (event.key === 'Escape') {
      const activeModal = document.querySelector('.modal.active');
      if (activeModal) {
        Utils.closeModal(activeModal.id);
      }
    }

    // Navigation with arrow keys (when no input focused)
    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
      const currentSection = window.dashboard?.getCurrentSection();
      if (currentSection === 'expenses' || currentSection === 'trips') {
        event.preventDefault();
        this.navigateItems(event.key === 'ArrowUp' ? 'up' : 'down');
      }
    }
  }

  handleGlobalClick(event) {
    // Handle clicks on dynamically generated elements
    const target = event.target.closest('[data-action]');
    if (target) {
      const action = target.dataset.action;
      const id = target.dataset.id;
      
      switch (action) {
        case 'approve-expense':
          window.expenseManager?.approveExpense(id);
          break;
        case 'approve-trip':
          window.expenseManager?.approveTrip(id);
          break;
        case 'edit-expense':
          window.expenseManager?.editExpense(id);
          break;
        case 'delete-expense':
          window.expenseManager?.confirmDeleteExpense(id);
          break;
        case 'delete-trip':
          window.expenseManager?.confirmDeleteTrip(id);
          break;
      }
    }
  }

  navigateItems(direction) {
    // Navigate through expense/trip items with keyboard
    const currentSection = window.dashboard?.getCurrentSection();
    const container = document.getElementById(`${currentSection}-list`);
    const items = container?.querySelectorAll('.item-card');
    
    if (!items || items.length === 0) return;
    
    const focusedItem = document.querySelector('.item-card.focused');
    let nextIndex = 0;
    
    if (focusedItem) {
      const currentIndex = Array.from(items).indexOf(focusedItem);
      nextIndex = direction === 'up' 
        ? Math.max(0, currentIndex - 1)
        : Math.min(items.length - 1, currentIndex + 1);
      
      focusedItem.classList.remove('focused');
    }
    
    items[nextIndex].classList.add('focused');
    items[nextIndex].scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  refreshData() {
    // Refresh data when tab becomes visible
    if (window.auth?.isAuthenticated()) {
      window.expenseManager?.loadData();
      window.dashboard?.update();
    }
  }

  handleBeforeUnload(event) {
    // Check for any unsaved form data
    const forms = document.querySelectorAll('form');
    let hasUnsavedData = false;
    
    forms.forEach(form => {
      if (form.checkValidity && form.checkValidity()) {
        const formData = new FormData(form);
        const hasData = Array.from(formData.values()).some(value => value.toString().trim());
        if (hasData) {
          hasUnsavedData = true;
        }
      }
    });
    
    if (hasUnsavedData) {
      event.preventDefault();
      event.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
      return event.returnValue;
    }
  }

  // Public API methods
  showSection(sectionName) {
    window.dashboard?.switchSection(sectionName);
  }

  addExpense(expenseData) {
    window.expenseManager?.addExpense(expenseData);
  }

  addTrip(tripData) {
    window.expenseManager?.addTrip(tripData);
  }

  exportData(format = 'csv') {
    if (format === 'pdf') {
      window.dashboard?.exportPDF();
    } else {
      window.dashboard?.exportCSV();
    }
  }

  // Debug helpers
  getStats() {
    if (!window.auth?.isAuthenticated()) {
      return { error: 'Not authenticated' };
    }
    
    const user = window.auth.getCurrentUser();
    const expenses = Utils.getFromStorage(`expenses_${user.id}`, []);
    const trips = Utils.getFromStorage(`trips_${user.id}`, []);
    
    return {
      user: user.name,
      expenses: expenses.length,
      trips: trips.length,
      totalAmount: expenses.reduce((sum, e) => sum + (parseFloat(e.amount) || 0), 0),
      pending: expenses.filter(e => e.status === 'pending').length,
      approved: expenses.filter(e => e.status === 'approved').length
    };
  }

  clearAllData() {
    if (!window.auth?.isAuthenticated()) {
      console.error('Not authenticated');
      return;
    }
    
    if (confirm('This will delete ALL your expenses and trips. This cannot be undone. Are you sure?')) {
      const user = window.auth.getCurrentUser();
      Utils.removeFromStorage(`expenses_${user.id}`);
      Utils.removeFromStorage(`trips_${user.id}`);
      
      window.expenseManager?.loadData();
      window.dashboard?.update();
      
      Utils.showToast('All data cleared successfully', 'success');
    }
  }

  // Version info
  getVersion() {
    return {
      app: 'ExpenseTracker',
      version: '1.0.0',
      built: new Date().toISOString().split('T')[0],
      features: [
        'Expense Management',
        'Trip Planning',
        'File Uploads',
        'Analytics Charts',
        'PDF/CSV Export',
        'Dark/Light Theme',
        'Responsive Design',
        'Local Storage'
      ]
    };
  }
}

// Initialize the application
window.addEventListener('load', () => {
  window.app = new App();
});

// Global helper functions for console debugging
window.debug = {
  getStats: () => window.app?.getStats(),
  clearData: () => window.app?.clearAllData(),
  version: () => window.app?.getVersion(),
  exportCSV: () => window.app?.exportData('csv'),
  exportPDF: () => window.app?.exportData('pdf'),
  showSection: (section) => window.app?.showSection(section),
  
  // Quick test data
  addTestExpense: () => {
    const expense = {
      id: Utils.generateId(),
      title: 'Test Expense',
      amount: Math.floor(Math.random() * 100) + 10,
      category: 'food',
      date: new Date().toISOString().split('T')[0],
      description: 'This is a test expense',
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    window.app?.addExpense(expense);
  },
  
  addTestTrip: () => {
    const trip = {
      id: Utils.generateId(),
      title: 'Test Trip',
      destination: 'Test City',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
      budget: Math.floor(Math.random() * 1000) + 500,
      purpose: 'business',
      description: 'This is a test trip',
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    window.app?.addTrip(trip);
  }
};

// Console welcome message
console.log(`
🎯 Welcome to ExpenseTracker!

Debug commands available:
- debug.getStats() - Get app statistics
- debug.version() - Get version info
- debug.addTestExpense() - Add a test expense
- debug.addTestTrip() - Add a test trip
- debug.exportCSV() - Export data to CSV
- debug.exportPDF() - Export data to PDF
- debug.showSection('section') - Navigate to section
- debug.clearData() - Clear all data (use with caution!)

Keyboard shortcuts:
- Ctrl/Cmd + N: Add expense
- Ctrl/Cmd + Shift + N: Add trip
- Ctrl/Cmd + D: Dashboard
- Ctrl/Cmd + E: Expenses
- Ctrl/Cmd + T: Trips
- Ctrl/Cmd + A: Analytics
- Ctrl/Cmd + R: Reports
- Esc: Close modal

Happy expense tracking! 💰
`);